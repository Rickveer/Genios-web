import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Mission from './components/Mission';
import Modules from './components/Modules';
import Countdown from './components/Countdown';
import Pricing from './components/Pricing';
import Waitlist from './components/Waitlist';
import Footer from './components/Footer';

export default function App() {
  return (
    <div className="relative min-h-screen bg-black text-white font-sans">
      {/* Noise overlay for premium texture */}
      <div className="noise-overlay" />

      <Navbar />
      <Hero />
      <Mission />
      <Modules />
      <Countdown />
      <Pricing />
      <Waitlist />
      <Footer />
    </div>
  );
}
