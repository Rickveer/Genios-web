import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useInView } from '../hooks/useInView';

function getTimeLeft() {
  const launchDate = new Date();
  launchDate.setMonth(launchDate.getMonth() + 3);
  launchDate.setHours(0, 0, 0, 0);

  const now = new Date();
  const diff = launchDate.getTime() - now.getTime();

  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
  const minutes = Math.floor((diff / (1000 * 60)) % 60);
  const seconds = Math.floor((diff / 1000) % 60);

  return { days, hours, minutes, seconds };
}

export default function Countdown() {
  const [time, setTime] = useState(getTimeLeft());
  const { ref, isInView } = useInView();

  useEffect(() => {
    const timer = setInterval(() => setTime(getTimeLeft()), 1000);
    return () => clearInterval(timer);
  }, []);

  const blocks = [
    { value: time.days, label: 'Days' },
    { value: time.hours, label: 'Hours' },
    { value: time.minutes, label: 'Minutes' },
    { value: time.seconds, label: 'Seconds' },
  ];

  return (
    <section className="relative py-24 overflow-hidden">
      <div ref={ref} className="max-w-4xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <span className="text-xs tracking-[0.3em] uppercase text-white/30 block mb-6">Beta Launch In</span>
          
          <div className="flex items-center justify-center gap-3 md:gap-6">
            {blocks.map((block, i) => (
              <div key={i} className="flex items-center gap-3 md:gap-6">
                <div className="relative">
                  <div className="w-20 h-24 md:w-28 md:h-32 rounded-xl border border-white/10 bg-white/[0.02] flex flex-col items-center justify-center">
                    <span className="font-display text-3xl md:text-5xl font-bold tabular-nums">
                      {String(block.value).padStart(2, '0')}
                    </span>
                    <span className="text-[9px] md:text-[10px] text-white/25 tracking-widest uppercase mt-1">
                      {block.label}
                    </span>
                  </div>
                </div>
                {i < blocks.length - 1 && (
                  <span className="text-white/15 text-2xl font-light">:</span>
                )}
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
