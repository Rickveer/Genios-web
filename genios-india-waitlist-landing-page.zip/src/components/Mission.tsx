import { motion } from 'framer-motion';
import { useInView } from '../hooks/useInView';

export default function Mission() {
  const { ref, isInView } = useInView();

  return (
    <section id="mission" className="relative py-32 overflow-hidden">
      <div className="gradient-line mb-32" />
      
      <div ref={ref} className="max-w-4xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center"
        >
          <span className="text-xs tracking-[0.3em] uppercase text-white/30 block mb-6">Our Mission</span>
          <h2 className="font-display text-3xl md:text-5xl lg:text-6xl font-bold leading-tight mb-8">
            Empowering every Indian creator to{' '}
            <span className="relative">
              <span className="relative z-10">build an empire</span>
              <span className="absolute bottom-1 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-white/50 to-transparent" />
            </span>
          </h2>
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-center text-lg md:text-xl text-white/40 leading-relaxed max-w-3xl mx-auto"
        >
          GENIOS empowers every Indian Gen Z creator to run a professional content business 
          without needing an agency, accountant, or business manager — all at the price of a Zomato order.
        </motion.p>

        {/* Decorative elements */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 1, delay: 0.5 }}
          className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-6"
        >
          {[
            { number: '01', title: 'No Agency Needed', desc: 'AI handles brand deals, negotiations, and content strategy automatically.' },
            { number: '02', title: 'No Accountant Needed', desc: 'India-specific GST, TDS, UPI — financial management built for Indian creators.' },
            { number: '03', title: 'No Manager Needed', desc: 'Community moderation, fan engagement, and monetization on autopilot.' },
          ].map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.3 + i * 0.15 }}
              className="group p-8 rounded-2xl border border-white/5 bg-white/[0.02] hover:bg-white/[0.04] hover:border-white/10 transition-all duration-500"
            >
              <span className="font-display text-sm text-white/20 block mb-4">{item.number}</span>
              <h3 className="font-display text-lg font-semibold mb-3 group-hover:text-white transition-colors">{item.title}</h3>
              <p className="text-sm text-white/30 leading-relaxed">{item.desc}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
