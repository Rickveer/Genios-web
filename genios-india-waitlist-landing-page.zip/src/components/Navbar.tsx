import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.8, ease: 'easeOut' }}
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-500 ${
        scrolled
          ? 'bg-black/80 backdrop-blur-xl border-b border-white/5'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-8 h-8 border border-white/30 rounded-lg flex items-center justify-center">
              <span className="font-display font-bold text-sm">G</span>
            </div>
          </div>
          <span className="font-display font-semibold text-lg tracking-tight">
            GENIOS<span className="text-white/40 ml-1 font-light">INDIA</span>
          </span>
        </div>
        <div className="hidden md:flex items-center gap-8 text-sm text-white/50">
          <a href="#mission" className="hover:text-white transition-colors duration-300">Mission</a>
          <a href="#modules" className="hover:text-white transition-colors duration-300">Product</a>
          <a href="#pricing" className="hover:text-white transition-colors duration-300">Pricing</a>
          <a href="#waitlist" className="hover:text-white transition-colors duration-300">
            <span className="px-4 py-2 border border-white/20 rounded-full hover:bg-white hover:text-black transition-all duration-300">
              Join Waitlist
            </span>
          </a>
        </div>
      </div>
    </motion.nav>
  );
}
