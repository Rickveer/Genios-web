import { motion } from 'framer-motion';
import { useInView } from '../hooks/useInView';
import {
  Handshake,
  BarChart3,
  Lightbulb,
  Calculator,
  Users,
  Sun,
  Brain,
  Heart,
  Target,
  UserCheck,
} from 'lucide-react';

const creatorFeatures = [
  {
    icon: Handshake,
    title: 'AI Brand Deal Manager',
    desc: 'Finds, rates, negotiates deals',
  },
  {
    icon: BarChart3,
    title: 'Multi-Platform Analytics Hub',
    desc: 'All data in one place',
  },
  {
    icon: Lightbulb,
    title: 'AI Content Strategy Engine',
    desc: '30+ ideas/month, trend detection',
  },
  {
    icon: Calculator,
    title: 'Financial & Tax Manager',
    desc: 'India-specific GST, TDS, UPI',
  },
  {
    icon: Users,
    title: 'Community & Fan Manager',
    desc: 'AI moderation and monetization',
  },
];

const lifeFeatures = [
  {
    icon: Sun,
    title: 'Morning Intelligence Briefing',
    desc: 'Personalized 7 AM summary',
  },
  {
    icon: Brain,
    title: 'Financial Brain',
    desc: 'Budget, savings, investment advice',
  },
  {
    icon: Heart,
    title: 'Energy & Health Optimizer',
    desc: 'Sleep, focus, productivity cycles',
  },
  {
    icon: Target,
    title: 'Goal Achievement System',
    desc: 'Big goals → daily micro-tasks',
  },
  {
    icon: UserCheck,
    title: 'Relationship Intelligence',
    desc: 'Fans, networking, birthdays',
  },
];

function FeatureCard({
  icon: Icon,
  title,
  desc,
  delay,
  isInView,
}: {
  icon: typeof Handshake;
  title: string;
  desc: string;
  delay: number;
  isInView: boolean;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={isInView ? { opacity: 1, x: 0 } : {}}
      transition={{ duration: 0.5, delay }}
      className="group flex items-start gap-4 p-4 rounded-xl hover:bg-white/[0.03] transition-all duration-300"
    >
      <div className="flex-shrink-0 w-10 h-10 rounded-lg border border-white/10 bg-white/[0.03] flex items-center justify-center group-hover:border-white/20 transition-colors">
        <Icon className="w-4 h-4 text-white/50 group-hover:text-white/80 transition-colors" />
      </div>
      <div>
        <h4 className="font-medium text-sm text-white/90 mb-1">{title}</h4>
        <p className="text-xs text-white/30">{desc}</p>
      </div>
    </motion.div>
  );
}

export default function Modules() {
  const { ref, isInView } = useInView();

  return (
    <section id="modules" className="relative py-32 overflow-hidden">
      <div className="gradient-line mb-32" />

      <div ref={ref} className="max-w-6xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-6"
        >
          <span className="text-xs tracking-[0.3em] uppercase text-white/30 block mb-6">What We Built</span>
          <h2 className="font-display text-3xl md:text-5xl font-bold mb-6">
            One subscription.<br />
            <span className="text-white/40">Two powerful modules.</span>
          </h2>
          <p className="text-white/30 max-w-2xl mx-auto">
            GENIOS is a single AI-powered SaaS subscription combining two powerful modules 
            designed to transform both your business and personal life.
          </p>
        </motion.div>

        <div className="mt-20 grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Module 1 */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative rounded-2xl border border-white/[0.08] bg-gradient-to-b from-white/[0.04] to-transparent p-8 md:p-10"
          >
            <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-white/20 to-transparent" />
            <div className="flex items-center gap-3 mb-2">
              <div className="px-3 py-1 rounded-full bg-white/10 text-[10px] tracking-widest uppercase font-medium">
                Module 1
              </div>
            </div>
            <h3 className="font-display text-2xl md:text-3xl font-bold mb-2">
              CreatorOS
            </h3>
            <p className="text-sm text-white/30 mb-8">Business Operations</p>

            <div className="space-y-1">
              {creatorFeatures.map((f, i) => (
                <FeatureCard key={i} {...f} delay={0.3 + i * 0.1} isInView={isInView} />
              ))}
            </div>
          </motion.div>

          {/* Module 2 */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="relative rounded-2xl border border-white/[0.08] bg-gradient-to-b from-white/[0.04] to-transparent p-8 md:p-10"
          >
            <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-white/20 to-transparent" />
            <div className="flex items-center gap-3 mb-2">
              <div className="px-3 py-1 rounded-full bg-white/10 text-[10px] tracking-widest uppercase font-medium">
                Module 2
              </div>
            </div>
            <h3 className="font-display text-2xl md:text-3xl font-bold mb-2">
              LifeAI
            </h3>
            <p className="text-sm text-white/30 mb-8">Personal Intelligence</p>

            <div className="space-y-1">
              {lifeFeatures.map((f, i) => (
                <FeatureCard key={i} {...f} delay={0.5 + i * 0.1} isInView={isInView} />
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
