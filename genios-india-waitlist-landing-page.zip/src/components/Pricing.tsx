import { motion } from 'framer-motion';
import { useInView } from '../hooks/useInView';
import { Check, Zap } from 'lucide-react';

export default function Pricing() {
  const { ref, isInView } = useInView();

  const features = [
    'AI Brand Deal Manager',
    'Multi-Platform Analytics',
    'Content Strategy Engine (30+ ideas/mo)',
    'Financial & Tax Manager (GST, TDS, UPI)',
    'Community & Fan Manager',
    'Morning Intelligence Briefing',
    'Financial Brain & Investment Advice',
    'Energy & Health Optimizer',
    'Goal Achievement System',
    'Relationship Intelligence',
  ];

  return (
    <section id="pricing" className="relative py-32 overflow-hidden">
      <div className="gradient-line mb-32" />

      <div ref={ref} className="max-w-4xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <span className="text-xs tracking-[0.3em] uppercase text-white/30 block mb-6">Pricing</span>
          <h2 className="font-display text-3xl md:text-5xl font-bold mb-4">
            Less than your daily<br />
            <span className="text-white/40">chai budget.</span>
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative max-w-lg mx-auto"
        >
          {/* Glow */}
          <div className="absolute -inset-1 bg-gradient-to-b from-white/10 via-white/5 to-transparent rounded-3xl blur-xl" />
          
          <div className="relative rounded-2xl border border-white/10 bg-black p-10">
            <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-white/30 to-transparent" />
            
            <div className="flex items-center gap-2 mb-6">
              <Zap className="w-5 h-5 text-white" />
              <span className="font-display font-semibold tracking-wider uppercase text-sm">GENIOS Complete</span>
            </div>

            <div className="flex items-baseline gap-1 mb-2">
              <span className="font-display text-6xl md:text-7xl font-bold">₹99</span>
              <span className="text-white/30 text-lg">/month</span>
            </div>
            <p className="text-sm text-white/30 mb-8">Both modules included. Cancel anytime.</p>

            <div className="space-y-3 mb-10">
              {features.map((feature, i) => (
                <div key={i} className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full border border-white/20 flex items-center justify-center flex-shrink-0">
                    <Check className="w-3 h-3 text-white/60" />
                  </div>
                  <span className="text-sm text-white/50">{feature}</span>
                </div>
              ))}
            </div>

            <a
              href="#waitlist"
              className="block w-full py-4 bg-white text-black font-semibold rounded-full text-center hover:shadow-[0_0_40px_rgba(255,255,255,0.15)] transition-all duration-300"
            >
              Join Waitlist — Get Early Access
            </a>

            <p className="text-center text-xs text-white/20 mt-4">
              Early members get 50% off for the first 6 months
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
