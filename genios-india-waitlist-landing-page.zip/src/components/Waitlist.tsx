import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { useInView } from '../hooks/useInView';
import { ArrowRight, CheckCircle, Loader2 } from 'lucide-react';

const WAITLIST_EMAIL = 'info.geniosz@gmail.com';
const AUTORESPONSE_MESSAGE =
  'Welcome to the GENIOS INDIA waitlist. You are now in line for beta access. We are launching in the next 3 months and will send early access details to this email first.';

export default function Waitlist() {
  const { ref, isInView } = useInView();
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [nextUrl, setNextUrl] = useState('');

  useEffect(() => {
    const currentUrl = new URL(window.location.href);
    setSubmitted(currentUrl.searchParams.get('joined') === '1');

    currentUrl.searchParams.set('joined', '1');
    currentUrl.hash = 'waitlist';
    setNextUrl(currentUrl.toString());
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    if (!email) {
      e.preventDefault();
      return;
    }

    // Let the browser post the form to FormSubmit so both notification emails are sent.
    setLoading(true);
  };

  return (
    <section id="waitlist" className="relative py-32 overflow-hidden">
      <div className="gradient-line mb-32" />

      {/* Background effects */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full radial-fade" />

      <div ref={ref} className="max-w-2xl mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <span className="text-xs tracking-[0.3em] uppercase text-white/30 block mb-6">Join the Movement</span>
          <h2 className="font-display text-3xl md:text-5xl lg:text-6xl font-bold mb-6">
            Be the first<br />
            <span className="text-white/40">to experience GENIOS.</span>
          </h2>
          <p className="text-white/30 max-w-md mx-auto">
            We're launching our beta in 3 months. Join the waitlist to get exclusive early access and founding member pricing.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          {!submitted ? (
            <form
              onSubmit={handleSubmit}
              action={`https://formsubmit.co/${WAITLIST_EMAIL}`}
              method="POST"
              className="space-y-4"
            >
              <input type="hidden" name="_subject" value="New GENIOS INDIA waitlist signup" />
              <input type="hidden" name="_template" value="table" />
              <input type="hidden" name="_replyto" value={email} />
              <input type="hidden" name="_autoresponse" value={AUTORESPONSE_MESSAGE} />
              <input type="hidden" name="_next" value={nextUrl} />
              <input type="hidden" name="Product" value="GENIOS INDIA Beta Waitlist" />
              <input type="hidden" name="Launch timeline" value="Beta in next 3 months" />
              <input type="text" name="_honey" className="hidden" tabIndex={-1} autoComplete="off" />
              <div className="relative">
                <input
                  type="text"
                  name="name"
                  placeholder="Your name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-6 py-4 rounded-xl bg-white/[0.04] border border-white/10 text-white placeholder:text-white/20 focus:border-white/30 transition-colors duration-300 text-sm"
                />
              </div>
              <div className="relative">
                <input
                  type="email"
                  name="email"
                  placeholder="Your email address"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full px-6 py-4 rounded-xl bg-white/[0.04] border border-white/10 text-white placeholder:text-white/20 focus:border-white/30 transition-colors duration-300 text-sm"
                />
              </div>
              <button
                type="submit"
                disabled={loading}
                className="w-full py-4 bg-white text-black font-semibold rounded-xl flex items-center justify-center gap-2 hover:shadow-[0_0_40px_rgba(255,255,255,0.15)] transition-all duration-300 disabled:opacity-70"
              >
                {loading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <>
                    Reserve My Spot
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
              <p className="text-center text-xs text-white/15">
                You will receive a confirmation email. GENIOS INDIA will receive your waitlist request at {WAITLIST_EMAIL}.
              </p>
            </form>
          ) : (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center py-12 px-8 rounded-2xl border border-white/10 bg-white/[0.02]"
            >
              <div className="w-16 h-16 rounded-full border border-white/20 flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-display text-2xl font-bold mb-3">You're on the list!</h3>
              <p className="text-white/40 text-sm">
                Welcome to the GENIOS family, {name || 'friend'}. We'll notify you 
                as soon as the beta is ready. Get ready to transform your creator journey.
              </p>
            </motion.div>
          )}
        </motion.div>

        {/* Social proof */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 1, delay: 0.5 }}
          className="mt-16 flex items-center justify-center gap-6"
        >
          <div className="flex -space-x-2">
            {[...Array(5)].map((_, i) => (
              <div
                key={i}
                className="w-8 h-8 rounded-full border-2 border-black bg-gradient-to-br from-white/20 to-white/5 flex items-center justify-center text-[10px] text-white/40 font-medium"
              >
                {String.fromCharCode(65 + i)}
              </div>
            ))}
          </div>
          <p className="text-xs text-white/30">
            <span className="text-white/60 font-medium">500+</span> creators already waiting
          </p>
        </motion.div>
      </div>
    </section>
  );
}
