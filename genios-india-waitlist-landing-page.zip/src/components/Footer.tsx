export default function Footer() {
  return (
    <footer className="relative py-16 border-t border-white/5">
      <div className="max-w-6xl mx-auto px-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="w-7 h-7 border border-white/20 rounded-lg flex items-center justify-center">
              <span className="font-display font-bold text-xs">G</span>
            </div>
            <span className="font-display font-semibold text-sm tracking-tight">
              GENIOS<span className="text-white/30 ml-1 font-light">INDIA</span>
            </span>
          </div>
          
          <div className="flex items-center gap-8 text-xs text-white/25">
            <a href="#mission" className="hover:text-white/60 transition-colors">Mission</a>
            <a href="#modules" className="hover:text-white/60 transition-colors">Product</a>
            <a href="#pricing" className="hover:text-white/60 transition-colors">Pricing</a>
            <a href="#waitlist" className="hover:text-white/60 transition-colors">Waitlist</a>
          </div>

          <p className="text-xs text-white/15">
            © 2025 Genios India. All rights reserved.
          </p>
        </div>

        <div className="mt-12 text-center">
          <p className="text-[10px] text-white/10 tracking-widest uppercase">
            Built for Indian Creators, by Indian Creators
          </p>
        </div>
      </div>
    </footer>
  );
}
